

public class PaperTechnician extends Thread {

    private ServicePrinter printer;

    public PaperTechnician(ThreadGroup threadGroup, ServicePrinter printer, String name) {
        super(threadGroup, name);
        this.printer = printer;
    }

    @Override
    public synchronized void run() {

        int randInt = (int) (Math.random() * 1000); //It will take a variable length of time between each step.
        int numofpaperUsed = 0;

        for (int i = 0; i < 3; i++) { //refill paper 3 time.

            printer.refillPaper();
            System.out.println("Paper Technician Refilling Paper");
            numofpaperUsed += 1;

            try {
                sleep(randInt);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Paper Technician Finished , packs of paper used : " + numofpaperUsed);
    }

}
