public class Student extends Thread {

    private Printer printer;

    public Student(ThreadGroup threadGroup, Printer printer, String name) {
        super(threadGroup, name);
        this.printer = printer;
    }

    @Override
    public synchronized void run() {

        Document Doc1 = new Document("DOC1", "Document1", 6);
        Document Doc2 = new Document("DOC2", "Document2", 9);
        Document Doc3 = new Document("DOC3", "Document3", 3);
        Document Doc4 = new Document("DOC4", "Document4", 7);
        Document Doc5 = new Document("DOC5", "Document5", 5);

        Document[] documents = new Document[5];
        documents[0] = Doc1;
        documents[1] = Doc2;
        documents[2] = Doc3;
        documents[3] = Doc4;
        documents[4] = Doc5;

        for (int i = 0; i < documents.length; i++) {

            int randInt = (int) (Math.random() * 1000);

            printer.printDocument(documents[i]);

            try {
                sleep(randInt);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
        System.out.println("Finished Printing Documents" +" "+ getName());

    }
}
