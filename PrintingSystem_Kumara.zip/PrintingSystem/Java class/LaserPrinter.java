

public class LaserPrinter implements ServicePrinter {

    private String IdPrinter;
    private int currentPaperLevel;
    private int currentTonerLevel;
    private int numberOfDocumentsPrinted;
    private ThreadGroup students;


    public LaserPrinter(String id, int paperlevel, int tonerlevel, ThreadGroup students) { // constructor
        this.IdPrinter = id;
        this.currentPaperLevel = paperlevel;//  paper level,toner level initial
        this.currentTonerLevel = tonerlevel;
        this.students = students;
        this.numberOfDocumentsPrinted = 0;
    }

    @Override
    public synchronized void replaceTonerCartridge() { // Toner tech replaces toner methodology

        if (!(currentTonerLevel  < ServicePrinter.Minimum_Toner_Level)) { // It will wait five seconds and attempt to change the toner even if it is not under 10.
            try {
                wait(5000);
            } catch (InterruptedException e) {
                System.out.println("_______________Interrupted thread________________");
            }


        if ((currentTonerLevel  < ServicePrinter.Minimum_Toner_Level)) { // replacements only if toner level is below 10
            this.currentTonerLevel  = ServicePrinter.Full_Toner_Level;
            Status("<Refilled Toner>: ");
        }

        notifyAll();
    }
    }

    @Override
    public synchronized void refillPaper() { //  replaces paper method paper tech
//      while (!(currentPprLvl < (ServicePrinter.Full_Paper_Tray - ServicePrinter.SheetsPerPack))) {
        if (currentPaperLevel > (ServicePrinter.Full_Paper_Tray - ServicePrinter.SheetsPerPack)) { //If the paper level is greater than 200, it will wait five seconds before attempting to replace it.
        try {
            wait(5000);
        } catch (InterruptedException e) {
            System.out.println("_______________Interrupted thread________________");
        }
    }

        while (this.currentPaperLevel < (ServicePrinter.Full_Paper_Tray - ServicePrinter.SheetsPerPack)) { // it will replace as many packs as it can before the printer its full without wasting paper
        this.currentPaperLevel = this.currentPaperLevel + ServicePrinter.SheetsPerPack;
            Status("<Refilled Paper>: ");
    }

    notifyAll();
}


    @Override

    public synchronized void printDocument(Document document) { // print document method student

        while ((currentPaperLevel < document.getNumberOfPages()) & (currentTonerLevel < document.getNumberOfPages())) { // if toner 0r paper  level is not enough it will wait
            try {
                wait();
            } catch (InterruptedException e) {
                System.out.println("_______________Interrupted thread________________");
            }
        }

        for (int i = 1; i <= document.getNumberOfPages(); i++) { // It will print page by page, using less paper and toner as necessary.
            this.currentPaperLevel--;
            this.currentTonerLevel--;
            Status("Printed Document Successfully(): " + document.getUserID() + "." + document.getDocumentName() + ".Page(" + i + "/" + document.getNumberOfPages());
        }
        this.numberOfDocumentsPrinted++;

        notifyAll();
        Status("Status -  "); //each print after prints the paper status
    }



    @Override
    public synchronized String toString() {
        return ( "LaserPrinter - [" +
                "PrinterID: '" + IdPrinter + '\'' + ", " +
                "Paper Level: " + currentPaperLevel + ", " +
                "Toner Level: " + currentTonerLevel + ", " +
                "Documents Printed: " + numberOfDocumentsPrinted +
                ']');
    }

    public void Status(String operation) {
        System.out.println("printer..." + "_  " +operation + this);
    }

}
