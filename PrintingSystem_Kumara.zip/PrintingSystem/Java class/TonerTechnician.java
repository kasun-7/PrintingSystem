

public class TonerTechnician extends Thread {

    private ServicePrinter printer;

    public TonerTechnician(ThreadGroup threadGroup, ServicePrinter printer, String name) {
        super(threadGroup, name);
        this.printer = printer;
    }

    @Override
    public synchronized void run() {

        int randInt = (int) (Math.random() * 1000);//It will take a variable length of time between each step.
        int tonerCartridgesUsed = 0;


        for (int i = 0; i < 3; i++) { //only makes 3 replacements for toner.

            printer.replaceTonerCartridge();
            System.out.println("Toner Technician replace Toner Cartridge");
            tonerCartridgesUsed  += 1;

           try {
                sleep(randInt);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Toner Technician Finished , cartridges replaced: " + tonerCartridgesUsed);
    }

}
