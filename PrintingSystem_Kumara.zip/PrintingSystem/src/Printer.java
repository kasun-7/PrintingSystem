public interface Printer
{

    // print the "document"
    public void printDocument( Document document ) ;

} // Printer