public class PrintingSystem {


    public static void main(String[] args) throws InterruptedException {

        ThreadGroup students    = new ThreadGroup("students");////the thread groupings are created
        ThreadGroup technicians = new ThreadGroup("technicians");

        System.out.println("Printing for Students & Technicians");

        ServicePrinter printer  = new LaserPrinter("SZHP###", 170, 200, students);//printer identification

        Thread student1 = new Student(students, printer, "student1");
        Thread student2 = new Student(students, printer, "student2");
        Thread student3 = new Student(students, printer, "student3");
        Thread student4 = new Student(students, printer, "student4");

        Thread paperTechnician = new PaperTechnician(technicians, printer, "paperTechnician");//technicians  created
        Thread tonerTechnician = new TonerTechnician(technicians, printer, "tonerTechnician");

        System.out.println("Start technicians and students");

        student1.start();
        student2.start();
        student3.start();
        student4.start();
        paperTechnician.start();
        tonerTechnician.start();

        System.out.println("Student Thread Active Count:" + students.activeCount() + "\ntechnicians Thread Active Count: " + technicians.activeCount());


        student1.join(); //wait for every thread to finish
        student2.join();
        student3.join();
        student4.join();
        paperTechnician.join();
        tonerTechnician.join();

        System.out.println( "_______________________________________________________________\n" +
                                   "***<Completed all tasks>***The printer's status\n"+
                            "\n"+
                                                    "PRINTER NOTE," );

        System.out.println(printer.toString());
    }

}
